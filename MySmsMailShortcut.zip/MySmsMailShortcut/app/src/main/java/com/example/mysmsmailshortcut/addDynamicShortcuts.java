package com.example.mysmsmailshortcut;

public class addDynamicShortcuts {
}
