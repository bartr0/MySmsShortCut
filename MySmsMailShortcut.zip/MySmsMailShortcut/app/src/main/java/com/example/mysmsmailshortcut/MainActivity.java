package com.example.mysmsmailshortcut;

import static android.widget.Toast.makeText;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.app.PendingIntent;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private static final String TAG = "SMS111";
    private static final int MY_PERMISSIONS_REQUEST_SEND = 1;
    private static final int MY_PERMISSIONS_RECEIVE_sms = 2;
    SmsManager smsManager;
    String destinationAddress = "";
    String scAddress = null;
    String text = "";
    PendingIntent sentIntent = null;
    PendingIntent deliveryIntent = null;
    long messageId = 0;
    private EditText tel;
    private EditText email;
    private EditText telTresc;
    private EditText emailTresc;
    Button button1;
    Button button2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        button1 = findViewById(R.id.button1);
        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sendWithSmsManager(view);
            }
        });
    }

    public void sendWithSmsManager(View view) {
        tel = findViewById(R.id.tel);
        email = findViewById(R.id.email);
        telTresc = findViewById(R.id.telTresc);
        emailTresc = findViewById(R.id.emailTresc);
        if (checkPermission(this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
            String text = telTresc.getText().toString();
            String destinationAddress = tel.getText().toString();
            if (!destinationAddress.equals("") && !text.equals("")) {
                smsManager = SmsManager.getDefault();

                smsManager.sendTextMessage(
                        destinationAddress,
                        null,
                        text,
                        null,
                        null

                );
                Toast.makeText(MainActivity.this, "SMS send", Toast.LENGTH_SHORT);
                Log.v(TAG, "SMS send");
            } else {
                Toast.makeText(MainActivity.this, "Permission denied", Toast.LENGTH_SHORT);
                Log.v(TAG, "Permission denied");
            }
        }
    }

    private int checkPermission(MainActivity mainActivity, String sendSms) {
        return 0;
    }

        private void sendSmsWithIntent(){
//            if (ContextCompat.checkSelfPermission(this, Manifest.permission.REQUESTED_PERMISSION) !=
//                    PackageManager.PERMISSION_GRANTED) {
            Log.v(TAG, "Prepare to send sms with Intent");
            destinationAddress = tel.getText().toString();
            text = telTresc.getText().toString();
            Intent intent = new Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:"));
            if (!destinationAddress.equals("") && !text.equals("")) {
                // intent.setData(Uri.parse("smsto:" + destinationAddress));
                intent.setType("vnd. android-dir/mms-sms");
                // intent.putExtra("address" , destinationAddress);
                intent.putExtra("sms_body", text);
                try {
                    startActivity(intent); // finish();
                    Log.v(TAG, "Finished sending SMS...");
                } catch (android.content.ActivityNotFoundException ex) {
                    Toast.makeText(MainActivity.this, "SMS faild, please try again later.", Toast.LENGTH_SHORT);

                }
            }
        }
    public void sendEmail(String mailBody){
        Intent mailIntent = new Intent(Intent.ACTION_SENDTO) ;
        mailIntent.setData(Uri.parse("mailto:"));
        mailIntent.putExtra(Intent.EXTRA_EMAIL,"Login@example.com") ;
        mailIntent.putExtra(Intent.EXTRA_SUBJECT, getString(R.string.subject));
        mailIntent.putExtra(Intent .EXTRA_TEXT, mailBody) ;
        startActivity(mailIntent) ;
}
}
