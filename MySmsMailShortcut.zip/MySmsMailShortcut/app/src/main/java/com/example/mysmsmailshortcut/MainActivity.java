package com.example.mysmsmailshortcut;

import static android.widget.Toast.makeText;

import androidx.appcompat.app.AppCompatActivity;

import android.Manifest;
import android.app.PendingIntent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private  static final String TAG = "SMS111";
    private static final int MY_PERMISSIONS_REQUEST_SEND = 1;
    private static final int MY_PERMISSIONS_RECEIVE_sms = 2;
    SmsManager smsManager;
    String destinationAddress = "";
    String scAddress = null;
    String text = "";
    PendingIntent sentIntent = null;
    PendingIntent deliveryIntent = null;
    long messageId = 0;
    EditText tel;
    EditText email;
    EditText telTresc;
    EditText emailTresc;
    Button button1;
    Button button2;

    private void sendWithSmsManager(){
        if(checkPermission(this, Manifest.permission.SEND_SMS)== PackageManager.PERMISSION_GRANTED){
            destinationAddress = tel.getText().toString();
            text = telTresc.getText().toString();
            if(!destinationAddress.equals("") && !text.equals("")){
                smsManager = SmsManager.getDefault();

                smsManager.sendTextMessage(
                        destinationAddress,
                        null,
                        text,
                        null,
                        null

                );
                Toast.makeText(MainActivity.this, "SMS send", Toast.LENGTH_SHORT);
                Log.v(TAG, "SMS send");
        } else {
                Toast.makeText(MainActivity.this, "Permission denied", Toast.LENGTH_SHORT);
                Log.v(TAG, "Permission denied");
            }
        }
    }

    private int checkPermission(MainActivity mainActivity, String sendSms) {
        return 0;
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
}